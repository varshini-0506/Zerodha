# backend/server.py

# Standard library imports
import asyncio
import json
import threading
import os
from typing import Dict, List, Optional
import pytz  # For timezone handling
from datetime import datetime, timedelta, time

# Third-party imports
from flask import Flask, jsonify, request
from flask_cors import CORS
import websockets
from kiteconnect import KiteConnect, KiteTicker
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = Flask(__name__)
CORS(app)

# Get credentials from environment variables
API_KEY = os.getenv('KITE_API_KEY')
ACCESS_TOKEN = os.getenv('KITE_ACCESS_TOKEN')

if not API_KEY or not ACCESS_TOKEN:
    raise ValueError("Please set KITE_API_KEY and KITE_ACCESS_TOKEN in .env file")

# Initialize Kite Connect
kite = KiteConnect(api_key=API_KEY)
kite.set_access_token(ACCESS_TOKEN)

# Store latest tick data
latest_ticks = {}

# Cache for instruments data
instruments_cache = {}
instruments_cache_timestamp = None

def get_all_instruments():
    """Get all available instruments from NSE"""
    global instruments_cache, instruments_cache_timestamp
    
    # Cache for 1 hour
    if (instruments_cache_timestamp and 
        (datetime.now() - instruments_cache_timestamp).seconds < 3600):
        return instruments_cache
    
    try:
        instruments = kite.instruments("NSE")
        instruments_cache = instruments
        instruments_cache_timestamp = datetime.now()
        print(f"Fetched {len(instruments)} instruments from NSE")
        return instruments
    except Exception as e:
        print(f"Error fetching instruments: {e}")
        return []

def get_popular_stocks():
    """Get list of popular stocks with basic info"""
    try:
        instruments = get_all_instruments()
        popular_symbols = [
            "RELIANCE", "TCS", "HDFCBANK", "INFY", "ICICIBANK",
            "HINDUNILVR", "HDFC", "SBIN", "BHARTIARTL", "ITC",
            "KOTAKBANK", "LT", "AXISBANK", "MARUTI", "ASIANPAINT",
            "WIPRO", "HCLTECH", "ULTRACEMCO", "TITAN", "BAJFINANCE",
            "TATAMOTORS", "SUNPHARMA", "POWERGRID", "TECHM", "NTPC",
            "ADANIENT", "ADANIPORTS", "BAJAJFINSV", "BAJAJ-AUTO", "COALINDIA"
        ]
        
        popular_stocks = []
        for instrument in instruments:
            if instrument['tradingsymbol'] in popular_symbols:
                stock_data = {
                    'symbol': instrument['tradingsymbol'],
                    'name': instrument['name'],
                    'instrument_token': instrument['instrument_token'],
                    'exchange': instrument['exchange'],
                    'instrument_type': instrument['instrument_type'],
                    'segment': instrument['segment'],
                    'expiry': instrument['expiry'],
                    'strike': instrument['strike'],
                    'tick_size': instrument['tick_size'],
                    'lot_size': instrument['lot_size']
                }
                popular_stocks.append(stock_data)
        
        return popular_stocks
    except Exception as e:
        print(f"Error getting popular stocks: {e}")
        return []

@app.route('/api/stocks', methods=['GET'])
def get_stocks():
    """Get all available stocks with pagination and search"""
    try:
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 50))
        search = request.args.get('search', '').upper()
        
        instruments = get_all_instruments()
        
        # Filter by search term if provided
        if search:
            instruments = [i for i in instruments if search in i['tradingsymbol'] or search in i['name'].upper()]
        
        # Pagination
        start_idx = (page - 1) * limit
        end_idx = start_idx + limit
        paginated_instruments = instruments[start_idx:end_idx]
        
        # Format response
        stocks = []
        for instrument in paginated_instruments:
            stock_data = {
                'symbol': instrument['tradingsymbol'],
                'name': instrument['name'],
                'instrument_token': instrument['instrument_token'],
                'exchange': instrument['exchange'],
                'instrument_type': instrument['instrument_type'],
                'segment': instrument['segment'],
                'expiry': instrument['expiry'],
                'strike': instrument['strike'],
                'tick_size': instrument['tick_size'],
                'lot_size': instrument['lot_size']
            }
            stocks.append(stock_data)
        
        return jsonify({
            'stocks': stocks,
            'total': len(instruments),
            'page': page,
            'limit': limit,
            'has_next': end_idx < len(instruments),
            'has_prev': page > 1
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/stocks/popular', methods=['GET'])
def get_popular_stocks_endpoint():
    """Get popular stocks"""
    try:
        stocks = get_popular_stocks()
        return jsonify({'stocks': stocks})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/stocks/<symbol>', methods=['GET'])
def get_stock_detail(symbol):
    """Get detailed information for a specific stock"""
    try:
        # Get instrument details
        instruments = get_all_instruments()
        instrument = None
        
        for inst in instruments:
            if inst['tradingsymbol'] == symbol.upper():
                instrument = inst
                break
        
        if not instrument:
            return jsonify({"error": "Stock not found"}), 404
        
        # Get quote data
        quote_data = None
        try:
            quote = kite.quote(f"NSE:{symbol.upper()}")
            if f"NSE:{symbol.upper()}" in quote:
                quote_data = quote[f"NSE:{symbol.upper()}"]
        except Exception as e:
            print(f"Error fetching quote for {symbol}: {e}")
        
        # Get historical data (last 30 days)
        historical_data = None
        try:
            from datetime import timedelta
            end_date = datetime.now()
            start_date = end_date - timedelta(days=30)
            
            historical = kite.historical_data(
                instrument_token=instrument['instrument_token'],
                from_date=start_date.date(),
                to_date=end_date.date(),
                interval='day'
            )
            historical_data = historical
        except Exception as e:
            print(f"Error fetching historical data for {symbol}: {e}")
        
        # Compile detailed stock information
        stock_detail = {
            'symbol': instrument['tradingsymbol'],
            'name': instrument['name'],
            'instrument_token': instrument['instrument_token'],
            'exchange': instrument['exchange'],
            'instrument_type': instrument['instrument_type'],
            'segment': instrument['segment'],
            'expiry': instrument['expiry'],
            'strike': instrument['strike'],
            'tick_size': instrument['tick_size'],
            'lot_size': instrument['lot_size'],
            'quote': quote_data,
            'historical_data': historical_data,
            'last_updated': datetime.now().isoformat()
        }
        
        return jsonify(stock_detail)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

from flask import jsonify
from datetime import datetime, timedelta, time
import pytz

@app.route('/api/quote/<symbol>', methods=['GET'])
def get_quote(symbol):
    try:
        # Get instrument token
        instruments = get_all_instruments()
        instrument_token = None
        for inst in instruments:
            if inst['tradingsymbol'] == symbol.upper():
                instrument_token = inst['instrument_token']
                break
        if not instrument_token:
            return jsonify({"error": "Symbol not found"}), 404

        ist = pytz.timezone('Asia/Kolkata')
        now = datetime.now(ist)
        market_open = time(9, 15)
        market_close = time(15, 30)

        # Determine the target trading day's date
        target_day = now.date()
        if now.time() < market_open:
            # Before market opens — fallback to previous trading day
            target_day -= timedelta(days=1)
        elif now.time() > market_close:
            # After market closes — use today's last candle
            pass
        else:
            # During market hours — fetch live quote
            try:
                quote = kite.quote(f"NSE:{symbol.upper()}")
                kite_data = quote.get(f"NSE:{symbol.upper()}", {})
                formatted_quote = {
                    "instrument_token": instrument_token,
                    "last_price": kite_data.get("last_price", 0),
                    "volume": kite_data.get("volume", 0),
                    "change": kite_data.get("change", 0),
                    "high": kite_data.get("ohlc", {}).get("high", 0),
                    "low": kite_data.get("ohlc", {}).get("low", 0),
                    "open": kite_data.get("ohlc", {}).get("open", 0),
                    "close": kite_data.get("ohlc", {}).get("close", 0),
                    "timestamp": kite_data.get("last_trade_time", now).isoformat()
                }
                return jsonify(formatted_quote)
            except Exception as e:
                print(f"Live quote error: {e}")
                # fallback to historical if live fails

        # === Historical fallback for today or previous trading day ===
        # Skip weekends
        while target_day.weekday() >= 5:
            target_day -= timedelta(days=1)

        from_date = ist.localize(datetime.combine(target_day, time(9, 15)))
        to_date = ist.localize(datetime.combine(target_day, time(15, 30)))

        candles = kite.historical_data(
            instrument_token,
            from_date,
            to_date,
            interval="day"
        )

        if candles:
            last_candle = candles[-1]
            formatted_quote = {
                "instrument_token": instrument_token,
                "last_price": last_candle["close"],
                "volume": last_candle["volume"],
                "change": round(((last_candle["close"] - last_candle["open"]) / last_candle["open"]) * 100, 2),
                "high": last_candle["high"],
                "low": last_candle["low"],
                "open": last_candle["open"],
                "close": last_candle["close"],
                "timestamp": last_candle["date"].isoformat()
            }
            return jsonify(formatted_quote)

        return jsonify({"error": "No candle data found"}), 404

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/market_status', methods=['GET'])
def get_market_status():
    """Get current market status"""
    try:
        return jsonify({
            "status": "success",
            "timestamp": datetime.now().isoformat(),
            "active_symbols": len(latest_ticks),
            "total_symbols": len(get_all_instruments()),
            "market_open": True  # You can add logic to check if market is open
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/search', methods=['GET'])
def search_stocks():
    """Search stocks by symbol or name"""
    try:
        query = request.args.get('q', '').strip()
        if not query:
            return jsonify({"error": "Query parameter 'q' is required"}), 400
        
        instruments = get_all_instruments()
        query_upper = query.upper()
        
        # Search by symbol or name
        results = []
        for instrument in instruments:
            if (query_upper in instrument['tradingsymbol'] or 
                query_upper in instrument['name'].upper()):
                stock_data = {
                    'symbol': instrument['tradingsymbol'],
                    'name': instrument['name'],
                    'instrument_token': instrument['instrument_token'],
                    'exchange': instrument['exchange'],
                    'instrument_type': instrument['instrument_type']
                }
                results.append(stock_data)
                
                # Limit results to 20
                if len(results) >= 20:
                    break
        
        return jsonify({'results': results, 'query': query})
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/news', methods=['GET'])
def get_news():
    """Get market news from multiple sources"""
    try:
        import requests
        from xml.etree import ElementTree
        
        news_items = []
        
        # Try to fetch from Zerodha Pulse RSS feed
        try:
            response = requests.get('https://pulse.zerodha.com/feed.php', timeout=10)
            if response.status_code == 200:
                root = ElementTree.fromstring(response.content)
                for item in root.findall('.//item'):
                    title = item.find('title')
                    link = item.find('link')
                    description = item.find('description')
                    pubDate = item.find('pubDate')
                    
                    if title is not None and link is not None:
                        news_items.append({
                            'title': title.text or '',
                            'link': link.text or '',
                            'description': description.text if description is not None else '',
                            'pubDate': pubDate.text if pubDate is not None else '',
                            'source': 'Zerodha Pulse'
                        })
        except Exception as e:
            print(f"Error fetching from Zerodha Pulse: {e}")
        
        # If no news from Zerodha, try alternative sources
        if not news_items:
            # Try MoneyControl RSS feed
            try:
                response = requests.get('https://www.moneycontrol.com/rss/business.xml', timeout=10)
                if response.status_code == 200:
                    root = ElementTree.fromstring(response.content)
                    for item in root.findall('.//item'):
                        title = item.find('title')
                        link = item.find('link')
                        description = item.find('description')
                        pubDate = item.find('pubDate')
                        
                        if title is not None and link is not None:
                            news_items.append({
                                'title': title.text or '',
                                'link': link.text or '',
                                'description': description.text if description is not None else '',
                                'pubDate': pubDate.text if pubDate is not None else '',
                                'source': 'MoneyControl'
                            })
            except Exception as e:
                print(f"Error fetching from MoneyControl: {e}")
        
        # If still no news, provide sample news
        if not news_items:
            news_items = [
                {
                    'title': 'Market Update: Sensex and Nifty show positive momentum',
                    'link': 'https://example.com/news1',
                    'description': 'Indian markets opened higher today with strong buying in banking and IT stocks.',
                    'pubDate': 'Mon, 23 Jun 2025 20:49:46 +0530',
                    'source': 'Market Update'
                },
                {
                    'title': 'RBI announces new monetary policy measures',
                    'link': 'https://example.com/news2',
                    'description': 'The Reserve Bank of India has announced new measures to support economic growth.',
                    'pubDate': 'Mon, 23 Jun 2025 19:30:00 +0530',
                    'source': 'RBI News'
                },
                {
                    'title': 'Global markets react to economic data',
                    'link': 'https://example.com/news3',
                    'description': 'International markets are responding to the latest economic indicators.',
                    'pubDate': 'Mon, 23 Jun 2025 18:15:00 +0530',
                    'source': 'Global Markets'
                }
            ]
        
        return jsonify({
            'news': news_items,
            'count': len(news_items),
            'timestamp': datetime.now().isoformat()
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

def on_ticks(ws, ticks):
    """Callback when ticks are received"""
    for tick in ticks:
        instrument_token = tick["instrument_token"]
        
        # Get instrument details for symbol
        symbol = None
        tradingsymbol = None
        for instrument in get_all_instruments():
            if instrument['instrument_token'] == instrument_token:
                symbol = instrument['tradingsymbol']
                tradingsymbol = instrument['tradingsymbol']
                break
        
        # Store tick data with symbol information
        latest_ticks[instrument_token] = {
            "instrument_token": instrument_token,
            "symbol": symbol,
            "tradingsymbol": tradingsymbol,
            "last_price": tick.get("last_price", 0),
            "ltp": tick.get("last_price", 0),  # Alternative field name
            "volume": tick.get("volume", 0),
            "change": tick.get("change", 0),
            "high": tick.get("high", 0),
            "low": tick.get("low", 0),
            "open": tick.get("open", 0),
            "close": tick.get("close", 0),
            "timestamp": datetime.now().isoformat()
        }
    print(f"Received ticks for {len(ticks)} instruments")

def on_connect(ws, response):
    """Callback when connection is established"""
    # Subscribe only to popular stocks to avoid exceeding the 4000 instrument limit
    popular_symbols = [
        "RELIANCE", "TCS", "HDFCBANK", "INFY", "ICICIBANK",
        "HINDUNILVR", "HDFC", "SBIN", "BHARTIARTL", "ITC",
        "KOTAKBANK", "LT", "AXISBANK", "MARUTI", "ASIANPAINT",
        "WIPRO", "HCLTECH", "ULTRACEMCO", "TITAN", "BAJFINANCE",
        "TATAMOTORS", "SUNPHARMA", "POWERGRID", "TECHM", "NTPC",
        "ADANIENT", "ADANIPORTS", "BAJAJFINSV", "BAJAJ-AUTO", "COALINDIA"
    ]
    instruments = get_all_instruments()
    instrument_tokens = [inst['instrument_token'] for inst in instruments if inst['tradingsymbol'] in popular_symbols]

    ws.subscribe(instrument_tokens)
    ws.set_mode(ws.MODE_FULL, instrument_tokens)

    print(f"WebSocket connected and subscribed to {len(instrument_tokens)} popular instruments")

def on_error(ws, code, reason):
    """Callback when error occurs"""
    print(f"WebSocket error. Code: {code}, Reason: {reason}")

def on_close(ws, code, reason):
    """Callback when connection closes"""
    print(f"WebSocket closed. Code: {code}, Reason: {reason}")

def start_kite_ws():
    """Start WebSocket connection with Kite"""
    kws = KiteTicker(API_KEY, ACCESS_TOKEN)
    kws.on_ticks = on_ticks
    kws.on_connect = on_connect
    kws.on_close = on_close
    kws.on_error = on_error
    
    while True:
        try:
            kws.connect(threaded=True)
            break
        except Exception as e:
            print(f"Error connecting to WebSocket: {e}")
            print("Retrying in 5 seconds...")
            import time
            time.sleep(5)

async def ws_handler(websocket, path):
    print(f"📲 New client connected to path: {path}")
    try:
        await websocket.send(json.dumps({
            "type": "market_status",
            "data": {
                "status": "connected",
                "timestamp": datetime.now().isoformat(),
                "total_instruments": len(get_all_instruments()),
                "path": path  # Log the path
            }
        }))
        while True:
            await asyncio.sleep(0.1)
            if latest_ticks:
                ticks_list = list(latest_ticks.values())
                await websocket.send(json.dumps({
                    "type": "tick_data",
                    "data": ticks_list,
                    "timestamp": datetime.now().isoformat()
                }))
    except websockets.exceptions.ConnectionClosed:
        print("❌ Client disconnected")
    except Exception as e:
        print(f"WebSocket error: {e}")
        try:
            await websocket.close()
        except:
            pass

def start_websocket_server():
    """Start WebSocket server for Flutter clients"""
    async def run_server():
        print("🟢 WebSocket server starting on ws://0.0.0.0:6789")
        async with websockets.serve(ws_handler, "0.0.0.0", 6789):
            await asyncio.Future()  # Keeps the server running forever

    asyncio.run(run_server())

if __name__ == "__main__":
    print("Starting Zerodha WebSocket streamer...")
    # Start WebSocket connection to Kite
    threading.Thread(target=start_kite_ws, daemon=True).start()
    # Start WebSocket server for clients
    threading.Thread(target=start_websocket_server, daemon=True).start()
    # Start Flask server
    #app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False)
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))

